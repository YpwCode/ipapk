# pngdefry

A fork of Jongware's [pngdefry](http://www.jongware.com/pngdefry.html)

Copyright (c) 2012 Jongware

Appknox is just having this repo here to customizing defry to our needs

## Compiling

Just run `make` from your terminal
